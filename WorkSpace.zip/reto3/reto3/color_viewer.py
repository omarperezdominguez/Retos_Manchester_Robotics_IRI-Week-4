#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Int8
import cv2
from cv_bridge import CvBridge
import numpy as np

class VisionNode(Node):
    def __init__(self):
        super().__init__('vision_node')
        
        self.subscription = self.create_subscription(
            Image,
            'video_source',
            self.image_callback,
            10)
            
        self.state_publisher = self.create_publisher(Int8, 'traffic_state', 10)
        self.debug_pub = self.create_publisher(Image, 'vision_debug', 10)
        
        self.bridge = CvBridge()
        self.current_state = 2 
        self.green_confirmations = 0 
        self.required_green_frames = 3 
        
        # Rangos HSV
        self.lower_red1 = np.array([0, 120, 70])
        self.upper_red1 = np.array([10, 255, 255])
        self.lower_red2 = np.array([160, 120, 70])
        self.upper_red2 = np.array([179, 255, 255])
        
        self.lower_yellow = np.array([15, 100, 100])
        self.upper_yellow = np.array([35, 255, 255])
        
        self.lower_green = np.array([40, 100, 100])
        self.upper_green = np.array([90, 255, 255])

        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        self.get_logger().info("Nodo de Visión Iniciado. Esperando imágenes en /video_source...")

    def process_color(self, hsv_img, lower, upper, lower2=None, upper2=None, debug_img=None, color_bgr=(0,0,0)):
        mask = cv2.inRange(hsv_img, lower, upper)
        if lower2 is not None and upper2 is not None:
            mask2 = cv2.inRange(hsv_img, lower2, upper2)
            mask = cv2.bitwise_or(mask, mask2)
            
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, self.kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        max_area = 0
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            max_area = cv2.contourArea(largest_contour)
            
            if max_area > 300 and debug_img is not None:
                cv2.drawContours(debug_img, [largest_contour], -1, color_bgr, 3)
                M = cv2.moments(largest_contour)
                if M["m00"] != 0:
                    cX = int(M["m10"] / M["m00"])
                    cY = int(M["m01"] / M["m00"])
                    cv2.putText(debug_img, f"Area: {int(max_area)}", (cX - 20, cY - 20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
                    
        return max_area, mask

    def image_callback(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            height, width = cv_image.shape[:2]
            
            # 1. Definir ROI
            roi_end_y = int(height/2)
            roi = cv_image[0:roi_end_y, 0:width]
            debug_roi = roi.copy()
            
            full_debug_img = cv_image.copy()
            cv2.rectangle(full_debug_img, (0, 0), (width, roi_end_y), (255, 0, 255), 2)
            cv2.putText(full_debug_img, "ZONA ROI", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)
            
            # 2. Procesamiento HSV
            hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
            
            area_red, mask_r = self.process_color(hsv, self.lower_red1, self.upper_red1, self.lower_red2, self.upper_red2, debug_roi, (0, 0, 255))
            area_yellow, mask_y = self.process_color(hsv, self.lower_yellow, self.upper_yellow, None, None, debug_roi, (0, 255, 255))
            area_green, mask_g = self.process_color(hsv, self.lower_green, self.upper_green, None, None, debug_roi, (0, 255, 0))
            
            full_debug_img[0:roi_end_y, 0:width] = debug_roi

            # 3. Máquina de Estados
            min_area_threshold = 300 
            new_state = self.current_state
            
            if area_red > min_area_threshold:
                new_state = 0 
                self.green_confirmations = 0
            elif area_yellow > min_area_threshold and self.current_state != 0:
                new_state = 1 
                self.green_confirmations = 0
            elif area_green > min_area_threshold:
                self.green_confirmations += 1
                if self.green_confirmations >= self.required_green_frames:
                    new_state = 2 
            
            self.current_state = new_state
            
            state_msg = Int8()
            state_msg.data = self.current_state
            self.state_publisher.publish(state_msg)

            # 4. Creación del Dashboard
            mask_r_bgr = cv2.cvtColor(mask_r, cv2.COLOR_GRAY2BGR)
            mask_y_bgr = cv2.cvtColor(mask_y, cv2.COLOR_GRAY2BGR)
            mask_g_bgr = cv2.cvtColor(mask_g, cv2.COLOR_GRAY2BGR)
            
            cv2.putText(mask_r_bgr, "MASCARA ROJA", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv2.putText(mask_y_bgr, "MASCARA AMARILLA", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.putText(mask_g_bgr, "MASCARA VERDE", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            dim = (320, 240)
            img1 = cv2.resize(full_debug_img, dim)
            img2 = cv2.resize(mask_r_bgr, dim)
            img3 = cv2.resize(mask_y_bgr, dim)
            img4 = cv2.resize(mask_g_bgr, dim)

            top_row = cv2.hconcat([img1, img2])
            bottom_row = cv2.hconcat([img3, img4])
            dashboard = cv2.vconcat([top_row, bottom_row])

            debug_msg = self.bridge.cv2_to_imgmsg(dashboard, encoding="bgr8")
            self.debug_pub.publish(debug_msg)

            states_str = {0: "ROJO (Stop)", 1: "AMARILLO (Lento)", 2: "VERDE (Go)"}
            self.get_logger().info(f'Estado: {states_str[self.current_state]} | R:{area_red:.0f} Y:{area_yellow:.0f} G:{area_green:.0f}')

        except Exception as e:
            self.get_logger().error(f"Error procesando imagen: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
