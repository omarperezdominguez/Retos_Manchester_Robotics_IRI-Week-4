#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge

class CameraNode(Node):
    def __init__(self):
        super().__init__('camera_node')
        # Publicamos la imagen en el tópico 'video_source'
        self.publisher_ = self.create_publisher(Image, 'video_source', 10)
        self.timer = self.create_timer(0.1, self.timer_callback) # 10 FPS
        self.bridge = CvBridge()
        
        # Pipeline optimizado para Jetson Nano y cámara CSI
        # Se eliminaron los espacios extra que causaban el IndentationError
        pipeline = (
            "nvarguscamerasrc ! "
            "video/x-raw(memory:NVMM), width=640, height=480, format=NV12, framerate=15/1 ! "
            "nvvidconv ! video/x-raw, format=BGRx ! videoconvert ! "
            "video/x-raw, format=BGR ! appsink drop=1"
        )
        
        self.get_logger().info('Iniciando captura con GStreamer (15 FPS)...')
        self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)

    def timer_callback(self):
        if not self.cap.isOpened():
            self.get_logger().error('¡Error: No se pudo abrir la cámara!')
            return

        ret, frame = self.cap.read()
        if ret:
            # Convertimos el frame de OpenCV a mensaje de ROS 2
            msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            self.publisher_.publish(msg)
        else:
            self.get_logger().warning('Frame no recibido')

    def __del__(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()

def main(args=None):
    rclpy.init(args=args)
    node = CameraNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
