import rclpy
from rclpy.node import Node
import math
import numpy as np
from geometry_msgs.msg import Pose
from std_msgs.msg import Bool

class PathGenerator(Node):

    def __init__(self):
        super().__init__('path_generator')
        
        # Parámetro de modo: square, triangle, pentagon, custom
        self.declare_parameter('mode', 'square')
        self.mode = self.get_parameter('mode').value
        
        self.goals = []
        self.current_index = 0
        
        # Generar la lista de metas según el modo
        self.generate_path()

        self.goal_pub = self.create_publisher(Pose, 'goal', 10)
        self.create_subscription(Bool, 'goal_reached', self.reached_callback, 10)

        # Timer para publicar la meta actual (1 Hz)
        self.timer = self.create_timer(1.0, self.publish_current_goal)
        
        self.get_logger().info(f"Path Generator iniciado en modo: {self.mode}")

    def generate_path(self):
        if self.mode == 'square':
            self.goals = [(1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0), (0.1, 0.0)]
        
        elif self.mode == 'triangle':
            # Triángulo equilátero de 1m de lado
            self.goals = [(1.0, 0.0), (0.5, 0.866), (0.0, 0.0), (0.1, 0.0)]
            
        elif self.mode == 'pentagon':
            L = 1.0 # Lado
            self.goals = [
                    (1.0, 0.0),
                (1.309, 0.951),
                (0.5, 1.539),
                (-0.309, 0.951),
                (0.0, 0.0),
                (0.1, 0.0)
            ]

        elif self.mode == 'custom':
            self.get_user_points()
            
        else:
            self.get_logger().warn("Modo desconocido, usando meta por defecto (1,0)")
            self.goals = [(1.0, 0.0)]

    def get_user_points(self):
        print("Puntos personalizados")
        try:
            n = int(input("Cuantos puntos quieres ingresar"))
            for i in range(n):
                print(f"Punto {i+1}:")
                x = float(input("X (m):"))
                y = float(input("Y (m): "))
                self.goals.append((x, y))
            if self.goals[-1] == (0.0, 0.0):
                self.goals.append((0.1, 0.0))
        except ValueError:
            self.get_logger().error("Entrada inválida. Usando meta (1,0)")
            self.goals = [(1.0, 0.0)]

    def publish_current_goal(self):
        if self.current_index >= len(self.goals):
            if self.current_index == len(self.goals):
                self.get_logger().info("¡Toda la trayectoria ha sido enviada!")
                self.current_index += 1 # Para que no repita el log
            return

        x, y = self.goals[self.current_index]

        msg = Pose()
        msg.position.x = x
        msg.position.y = y
        msg.orientation.w = 1.0

        self.goal_pub.publish(msg)
        self.get_logger().info(f'Enviando Meta {self.current_index+1}/{len(self.goals)}: ({x},{y})')

    def reached_callback(self, msg):
        if msg.data:
            self.current_index += 1
            if self.current_index < len(self.goals):
                self.get_logger().info(f"Cambiando a Meta {self.current_index+1}")

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
