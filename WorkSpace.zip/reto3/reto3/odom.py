import rclpy
import numpy as np
import transforms3d

from rclpy import qos
from rclpy.node import Node
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry

class Odom(Node):

    def __init__(self):
        super().__init__('odom')

        #Variables de estado (Pose)
        self.x = 0.0
        self.y = 0.0
        self.th = 0.0

        #Parametros fisicos 
        self.r = 0.05
        self.l = 0.1615 # Distancia entre llantas
        self.sample_time = 0.01

        #Velocidades
        self.wr = 0.0
        self.wl = 0.0
        self.V = 0.0
        self.Omega = 0.0

        self.first = True
        self.last_time = self.get_clock().now()

        # Suscripciones
        self.create_subscription(
            Float32, 'VelocityEncR', self.encR_callback, qos.qos_profile_sensor_data
        )
        self.create_subscription(
            Float32, 'VelocityEncL', self.encL_callback, qos.qos_profile_sensor_data
        )

        # Publicador de Odometría
        self.odom_pub = self.create_publisher(Odometry, 'odom', 10)
        
        # Timer de ejecución (200 Hz)
        self.timer = self.create_timer(0.005, self.run)

    def encR_callback(self, msg):
        self.wr = msg.data

    def encL_callback(self, msg):
        self.wl = msg.data

    def wrap_to_pi(self, angle):
        return np.arctan2(np.sin(angle), np.cos(angle))

    def run(self):
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds * 1e-9

        if self.first:
            self.first = False
            self.last_time = current_time
            return

        if dt < self.sample_time:
            return

        # 1. Calcular velocidades lineales de cada rueda
        vr = self.r * self.wr
        vl = self.r * self.wl

        # 2. Modelo cinemático diferencial
        self.V = 0.5 * (vr + vl)
        self.Omega = (vr - vl) / self.l

        # 3. Metodo de euler para  posicion y orientacion
        self.x += self.V * np.cos(self.th) * dt
        self.y += self.V * np.sin(self.th) * dt
        self.th += self.Omega * dt
        self.th = self.wrap_to_pi(self.th)

        th_degrees = np.degrees(self.th)
        self.last_time = current_time
        self.get_logger().info(
                f"Vels: wr={self.wr:.2f}, wl={self.wl:.2f} | Pose: x={self.x:.2f}, y={self.y:.2f}, th_deg={th_degrees:.1f}°",
            throttle_duration_sec=0.5
        )

        self.publish_odom()
    
    def publish_odom(self):
        msg = Odometry()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'odom'
        msg.child_frame_id = 'base_footprint'
        # transforms3d devuelve (w, x, y, z)
        q = transforms3d.euler.euler2quat(0, 0, self.th)

        # Pose: Posicion
        msg.pose.pose.position.x = self.x
        msg.pose.pose.position.y = self.y
        msg.pose.pose.position.z = 0.0

        # Pose: Orientacion (Cuaternion)
        msg.pose.pose.orientation.w = q[0]
        msg.pose.pose.orientation.x = q[1]
        msg.pose.pose.orientation.y = q[2]
        msg.pose.pose.orientation.z = q[3]

        # Twist: Velocidades
        msg.twist.twist.linear.x = self.V
        msg.twist.twist.angular.z = self.Omega

        self.odom_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = Odom()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
