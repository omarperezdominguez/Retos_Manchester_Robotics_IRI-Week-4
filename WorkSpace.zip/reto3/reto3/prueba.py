import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np
from rclpy import qos


class WheelCalibrator(Node):

    def __init__(self):
        super().__init__('wheel_calibrator')

        self.wr = 0.0
        self.wl = 0.0

        # Buffers para guardar datos
        self.wr_list = []
        self.wl_list = []

        # Tiempo de calibración (segundos)
        self.calibration_time = 10.0

        self.start_time = None

        # Subscripciones
        self.create_subscription(Float32, 'VelocityEncR', self.encR_callback, qos.qos_profile_sensor_data)
        self.create_subscription(Float32, 'VelocityEncL', self.encL_callback, qos.qos_profile_sensor_data)

        # Timer
        self.timer = self.create_timer(0.01, self.run)

        self.get_logger().info("🔧 Wheel Calibrator listo.")
        self.get_logger().info("👉 Haz que el robot gire en su lugar durante 10 segundos.")

    def encR_callback(self, msg):
        self.wr = msg.data

    def encL_callback(self, msg):
        self.wl = msg.data

    def run(self):
        now = self.get_clock().now().nanoseconds * 1e-9

        if self.start_time is None:
            self.start_time = now
            return

        elapsed = now - self.start_time

        # Guardar datos SOLO si está girando
        if abs(self.wr) > 0.1 or abs(self.wl) > 0.1:
            self.wr_list.append(self.wr)
            self.wl_list.append(self.wl)

        if elapsed >= self.calibration_time:
            self.compute_calibration()
            self.timer.cancel()

    def compute_calibration(self):
        wr_mean = np.mean(self.wr_list)
        wl_mean = np.mean(self.wl_list)

        self.get_logger().info(f"\n📊 Promedios:")
        self.get_logger().info(f"wr_mean = {wr_mean:.4f}")
        self.get_logger().info(f"wl_mean = {wl_mean:.4f}")

        # Idealmente: wr = -wl
        # Entonces normalizamos
        scale_r = 1.0 / abs(wr_mean)
        scale_l = 1.0 / abs(wl_mean)

        # Normalizamos respecto a la rueda izquierda
        kr = abs(wl_mean) / abs(wr_mean)
        kl = 1.0

        self.get_logger().info("\n✅ Factores de corrección sugeridos:")
        self.get_logger().info(f"kr = {kr:.4f}")
        self.get_logger().info(f"kl = {kl:.4f}")

        self.get_logger().info("\n👉 Úsalos así en tu nodo de odom:")
        self.get_logger().info("vr = r * kr * wr")
        self.get_logger().info("vl = r * kl * wl")


def main(args=None):
    rclpy.init(args=args)
    node = WheelCalibrator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
