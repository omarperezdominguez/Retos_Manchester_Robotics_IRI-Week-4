#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Int8
import cv2
from cv_bridge import CvBridge
import numpy as np

class TrafficLightDetectorNode(Node):
    def __init__(self):
        super().__init__('traffic_light_detector')
        
        # --- Configuración de ROS 2 ---
        self.state_publisher = self.create_publisher(Int8, 'traffic_state', 10)
        self.debug_pub = self.create_publisher(Image, 'vision_debug', 10)
        
        # Procesamiento a 10 FPS (1 frame cada 100ms)
        self.timer = self.create_timer(0.1, self.process_loop)
        self.bridge = CvBridge()
        
        # --- Parámetros de Estado y Filtro de Persistencia ---
        self.current_state = 2  # Iniciamos en VERDE (2)
        self.confirmation_counters = {0: 0, 1: 0, 2: 0} # Contadores para R, Y, G
        self.frames_to_confirm = 5 # El color debe repetirse 5 frames para cambiar el estado
        
        # --- UMBRALES INDEPENDIENTES POR COLOR (DISTANCIA) ---
        self.thresholds = {
            0: 100000, # Umbral para ROJO
            1: 65000,  # Umbral para AMARILLO
            2: 45000   # Umbral para VERDE
        }
        
        # --- Rangos HSV Calibrados ---
        self.lower_red1 = np.array([0, 120, 70]); self.upper_red1 = np.array([10, 255, 255])
        self.lower_red2 = np.array([160, 120, 70]); self.upper_red2 = np.array([179, 255, 255])
        self.lower_yellow = np.array([10, 50, 50]); self.upper_yellow = np.array([45, 255, 255])
        self.lower_green = np.array([40, 100, 100]); self.upper_green = np.array([90, 255, 255])

        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))

        # --- Pipeline GStreamer para Cámara CSI (Jetson Nano) ---
        pipeline = (
            "nvarguscamerasrc ! "
            "video/x-raw(memory:NVMM), width=640, height=480, format=NV12, framerate=15/1 ! "
            "nvvidconv ! video/x-raw, format=BGRx ! videoconvert ! "
            "video/x-raw, format=BGR ! appsink drop=1"
        )
        
        self.get_logger().info('Iniciando Visión con Filtro de Persistencia...')
        self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)

    def process_color(self, hsv_img, lower, upper, lower2=None, upper2=None):
        """Aísla un color y retorna el área del contorno más grande."""
        mask = cv2.inRange(hsv_img, lower, upper)
        if lower2 is not None and upper2 is not None:
            mask2 = cv2.inRange(hsv_img, lower2, upper2)
            mask = cv2.bitwise_or(mask, mask2)
            
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, self.kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        max_area = 0
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            max_area = cv2.contourArea(largest_contour)
        return max_area, mask

    def process_loop(self):
        if not self.cap.isOpened(): return

        ret, frame = self.cap.read()
        if not ret: return

        try:
            # 1. Definir ROI (mitad superior de la imagen)
            height, width = frame.shape[:2]
            roi_end_y = int(height/2)
            roi = frame[0:roi_end_y, 0:width]
            
            # 2. Procesar Colores en HSV
            hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
            area_r, _ = self.process_color(hsv, self.lower_red1, self.upper_red1, self.lower_red2, self.upper_red2)
            area_y, _ = self.process_color(hsv, self.lower_yellow, self.upper_yellow)
            area_g, _ = self.process_color(hsv, self.lower_green, self.upper_green)

            # 3. Lógica de Decisión (Filtro por color dominante y umbral)
            areas = {0: area_r, 1: area_y, 2: area_g}
            color_detectado = max(areas, key=areas.get)
            area_maxima = areas[color_detectado]
            
            umbral_especifico = self.thresholds.get(color_detectado, 50000)
            
            # Determinar el estado "deseado" basado en la imagen actual
            if area_maxima > umbral_especifico:
                dist_label = "CERCA"
                target_state = color_detectado
            else:
                dist_label = "LEJOS"
                target_state = 2 # Si está lejos, el objetivo es seguir avanzando (Verde)

            # --- FILTRO DE PERSISTENCIA ---
            if target_state != self.current_state:
                # Si el color que vemos es distinto al que estamos publicando, sumamos al contador
                self.confirmation_counters[target_state] += 1
                
                # Limpiamos los otros contadores para asegurar que la detección sea consecutiva
                for color in self.confirmation_counters:
                    if color != target_state:
                        self.confirmation_counters[color] = 0

                # Si el color nuevo se mantiene por N frames, hacemos el cambio oficial
                if self.confirmation_counters[target_state] >= self.frames_to_confirm:
                    self.current_state = target_state
                    self.confirmation_counters = {0: 0, 1: 0, 2: 0}
            else:
                # Si el color detectado es el mismo que ya publicamos, reseteamos contadores
                self.confirmation_counters = {0: 0, 1: 0, 2: 0}

            # 4. Publicar el estado ya filtrado y estable
            msg = Int8()
            msg.data = self.current_state
            self.state_publisher.publish(msg)

            # 5. Visualización de Debug
            if self.debug_pub.get_subscription_count() > 0:
                cv2.putText(frame, f"Visto: {color_detectado} Area: {int(area_maxima)}", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                cv2.putText(frame, f"Conf: {self.confirmation_counters[target_state]}/{self.frames_to_confirm}", (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)
                debug_msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
                self.debug_pub.publish(debug_msg)

            # Log informativo
            st_names = {0: "ROJO", 1: "AMARILLO", 2: "VERDE"}
            self.get_logger().info(
                f'[{dist_label}] Dominante: {st_names[color_detectado]} | Conf: {self.confirmation_counters[target_state]}/{self.frames_to_confirm} | Enviando: {st_names[self.current_state]}'
            )

        except Exception as e:
            self.get_logger().error(f"Error en el loop: {e}")

    def __del__(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()

def main(args=None):
    rclpy.init(args=args)
    node = TrafficLightDetectorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()