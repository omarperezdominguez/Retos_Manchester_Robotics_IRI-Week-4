import rclpy
import numpy as np
import transforms3d

from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool, Int8

class Controller(Node):

    def __init__(self):
        super().__init__('controller')
        self.declare_parameter('kv', 0.8)
        self.declare_parameter('kw', 4.5)
        self.declare_parameter('max_v', 0.15)
        self.declare_parameter('max_w', 0.3)
        self.declare_parameter('dist_tolerance', 0.05)

        self.kv = self.get_parameter('kv').value
        self.kw = self.get_parameter('kw').value
        self.max_v = self.get_parameter('max_v').value
        self.max_w = self.get_parameter('max_w').value
        self.dist_tolerance = self.get_parameter('dist_tolerance').value
        
        self.traffic_state = 2
        self.speed_multiplier = 1.0 
        
        self.x, self.y, self.th = 0.0, 0.0, 0.0
        self.goal_x, self.goal_y = 0.0, 0.0
        self.goal_active = False
        self.goal_reached_once = False

        self.create_subscription(Odometry, 'odom', self.odom_callback, 10)
        self.create_subscription(Pose, 'goal', self.goal_callback, 10)
        self.create_subscription(Int8, 'traffic_state', self.traffic_callback, 10)
        
        self.cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.reached_pub = self.create_publisher(Bool, 'goal_reached', 10)

        self.timer = self.create_timer(0.02, self.control_loop)
        self.get_logger().info("Controlador iniciado y esperando meta")

    def traffic_callback(self, msg):
        self.traffic_state = msg.data
        states = {0: "Rojo", 1: "Amarillo", 2: "Verde"}
        
        if self.traffic_state == 0:
            self.speed_multiplier = 0.0
        elif self.traffic_state == 1:
            self.speed_multiplier = 0.35
        else:
            self.speed_multiplier = 1.0
        
        self.get_logger().info(f"Semáforo: {states.get(msg.data, 'Desconocido')}", throttle_duration_sec=2.0)

    def wrap_to_pi(self, angle):
        return np.arctan2(np.sin(angle), np.cos(angle))

    def saturate(self, value, limit):
        return max(min(value, limit), -limit)

    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        q = msg.pose.pose.orientation
        euler = transforms3d.euler.quat2euler([q.w, q.x, q.y, q.z])
        self.th = euler[2]

    def goal_callback(self, msg):
        self.goal_x = msg.position.x
        self.goal_y = msg.position.y
        self.goal_active = True
        self.goal_reached_once = False
        self.get_logger().info(f"Nueva meta recibida: x={self.goal_x:.2f}, y={self.goal_y:.2f}")

    def control_loop(self):
        cmd = Twist()
        reached_msg = Bool()
        reached_msg.data = False

        if not self.goal_active:
            self.cmd_pub.publish(cmd)
            return

        ex = self.goal_x - self.x
        ey = self.goal_y - self.y
        ed = np.hypot(ex, ey)
        desired_heading = np.arctan2(ey, ex)
        etheta = self.wrap_to_pi(desired_heading - self.th)

        if ed < self.dist_tolerance:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            if not self.goal_reached_once:
                reached_msg.data = True
                self.goal_reached_once = True
                self.get_logger().info("Meta alcanzada")
        else:
            if self.traffic_state == 0:
                self.get_logger().info("Esperando en rojo", throttle_duration_sec=5.0)

            w_val = self.kw * etheta
            min_w = 0.28
            if abs(etheta) > 0.02:
                if abs(w_val) < min_w:
                    w_val = min_w if etheta > 0 else -min_w
            
            cmd.angular.z = self.saturate(w_val, self.max_w) * self.speed_multiplier

            if abs(etheta) < 0.15:
                v_base = self.kv * ed
                v_out = self.saturate(v_base * np.cos(etheta), self.max_v)
                cmd.linear.x = v_out * self.speed_multiplier
            else:
                cmd.linear.x = 0.0
        
        self.cmd_pub.publish(cmd)
        self.reached_pub.publish(reached_msg)

def main(args=None):
    rclpy.init(args=args)
    node = Controller()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
