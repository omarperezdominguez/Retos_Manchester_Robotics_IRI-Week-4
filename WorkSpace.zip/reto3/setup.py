from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'reto3'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']), # Esto ahora encontrará la carpeta 'reto3' correctamente
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Mario Martinez',
    description='Half Term Challenge: Vision and Navigation',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'controller_node = reto3.controller:main',
            'path_generator = reto3.path:main',
            'vision_node = reto3.vision_node:main',
            'odom_node = reto3.odom:main',
            'prueba = reto3.prueba:main',
            'camera_node = reto3.camera_node:main',
            'color_viewer = reto3.color_viewer:main',
            'semaforo_node = reto3.semaforo:main',

        ],
    },
)
